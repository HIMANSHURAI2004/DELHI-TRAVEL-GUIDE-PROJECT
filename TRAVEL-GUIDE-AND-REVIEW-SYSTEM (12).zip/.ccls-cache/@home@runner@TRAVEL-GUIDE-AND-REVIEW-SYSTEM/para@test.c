#include <stdio.h>
int main() {
  FILE *file = fopen("detail.txt", "r"); // Open the file in read mode
  if (file == NULL) {
    printf("Error opening the file.\n");
    return 1;
  }

  int paragraphCount = 0;
  int paragraphToRead = 1;
  char line[100];

  // Read the file line by line
  while (fgets(line, sizeof(line), file)) {
    // Check for an empty line to detect paragraph breaks
    if (line[0] == '\n') {
      paragraphCount++;
    }

    // If the current paragraph count matches the desired paragraph, print the
    // line
    if (paragraphCount == paragraphToRead) {
      printf("%s", line);
    }
  }

  fclose(file); // Close the file
  return 0;
}
