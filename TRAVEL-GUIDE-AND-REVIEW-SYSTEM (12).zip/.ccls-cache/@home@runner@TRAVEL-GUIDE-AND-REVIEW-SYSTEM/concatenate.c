#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_PARAGRAPH_SIZE 1000

int main() {
    FILE* file = fopen("filename.txt", "r");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return 1; // Exit the program with an error status
    }

    // Read the entire file into memory
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    rewind(file);
    char* file_content = (char*)malloc((file_size + 1) * sizeof(char));
    fread(file_content, sizeof(char), file_size, file);
    file_content[file_size] = '\0';

    // Close the file
    fclose(file);

    // Tokenize the file content based on paragraph separator (e.g., "\n\n")
    const char* paragraph_delimiter = "\n\n";
    char* paragraph = strtok(file_content, paragraph_delimiter);
    int paragraph_count = 0;

    // Access and process each paragraph separately
    while (paragraph != NULL) {
        paragraph_count++;

        // Print or process the paragraph as needed
        printf("Paragraph %d:\n%s\n\n", paragraph_count, paragraph);

        // Move to the next paragraph
        paragraph = strtok(NULL, paragraph_delimiter);
    }

    // Free the memory allocated for file content
    free(file_content);

    return 0; // Exit the program successfully
}
