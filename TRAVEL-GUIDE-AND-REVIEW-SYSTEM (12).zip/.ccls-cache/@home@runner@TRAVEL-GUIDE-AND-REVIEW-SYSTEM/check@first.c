#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERNAME_LENGTH 20
#define MAX_PASSWORD_LENGTH 20
#define DATABASE_FILE "users.txt"

typedef struct {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
} User;

int is_user_exist(const char* username) {
    FILE* file = fopen(DATABASE_FILE, "r");
    if (file == NULL) {
        return 0;
    }

    char line[MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH + 2];
    while (fgets(line, sizeof(line), file) != NULL) {
        char* token = strtok(line, " ");
        if (token != NULL && strcmp(token, username) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

int add_user(const User* user) {
    if (is_user_exist(user->username)) {
        return 0;
    }

    FILE* file = fopen(DATABASE_FILE, "a");
    if (file == NULL) {
        return 0;
    }

    fprintf(file, "%s %s\n", user->username, user->password);
    fclose(file);

    return 1;
}

int authenticate(const User* user) {
    FILE* file = fopen(DATABASE_FILE, "r");
    if (file == NULL) {
        return 0;
    }

    char line[MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH + 2];
    while (fgets(line, sizeof(line), file) != NULL) {
        char* saved_username = strtok(line, " ");
        char* saved_password = strtok(NULL, " \n");

        if (saved_username != NULL && saved_password != NULL &&
            strcmp(saved_username, user->username) == 0 &&
            strcmp(saved_password, user->password) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

int reset_password(const char* username, const char* new_password) {
    FILE* file = fopen(DATABASE_FILE, "r");
    if (file == NULL) {
        return 0;
    }

    FILE* temp_file = fopen("temp.txt", "w");
    if (temp_file == NULL) {
        fclose(file);
        return 0;
    }

    char line[MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH + 2];
    while (fgets(line, sizeof(line), file) != NULL) {
        char* saved_username = strtok(line, " ");
        char* saved_password = strtok(NULL, " \n");

        if (saved_username != NULL && saved_password != NULL &&
            strcmp(saved_username, username) == 0) {
            fprintf(temp_file, "%s %s\n", saved_username, new_password);
        } else {
            fprintf(temp_file, "%s %s\n", saved_username, saved_password);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (remove(DATABASE_FILE) != 0) {
        return 0;
    }

    if (rename("temp.txt", DATABASE_FILE) != 0) {
        return 0;
    }

    return 1;
}

int main() {
    int choice;
    User user;
    
    //printf("\t\t\t ----------------------------------\n\t\t\t|| TRAVEL GUIDE AND REVIEW SYSTEM ||\n\t\t\t ----------------------------------\n");
    printf("\t\t\t1. Sign up\n");
    printf("\t\t\t2. Login\n");
    printf("\t\t\t3. Forgot Password\n");
    printf("\tEnter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            printf("Enter username: ");
            scanf("%s", user.username);
            printf("Enter password: ");
            scanf("%s", user.password);

            if (add_user(&user)) {
                printf("User created successfully.\n");
            } else {
                printf("Failed to create user. Please try again later.\n");
            }
            break;

        case 2:
            printf("Enter username: ");
            scanf("%s", user.username);
            printf("Enter password: ");
            scanf("%s", user.password);

            if (authenticate(&user)) {
                printf("Login successful.\n");
            } else {
                printf("Invalid username or password.\n");
            }
            break;
       case 3:
            printf("Enter username: ");
            scanf("%s", user.username);
            printf("Enter password: ");
            scanf("%s", user.password);
           if (reset_password(&user,&user.password)) {
                printf("Password changed successfully.\n");
            } else {
                printf("Failed to change password. Please try again later.\n");
            }
            break;
        default:
            printf("Invalid choice.\n");
            break;
    }
  printf("\t\t\tTOURIST PLACES\t\t\t\n");
  printf("Red Fort\n");
  printf("Indian Gate\n");
  printf("Jama Masjid\n");
  printf("Qutub Minar\n");
    return 0;
}