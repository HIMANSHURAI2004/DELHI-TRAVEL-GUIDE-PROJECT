#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char username[50];
    char password[50];
} User;

void addUser(User user) {
    FILE *file = fopen("username_password.txt", "a");
    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }
    fprintf(file, "%s,%s\n", user.username, user.password);
    fclose(file);
}

int authenticateUser(User user) {
    FILE *file = fopen("username_password.txt", "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        return 0;
    }
    char line[100];
    while (fgets(line, sizeof(line), file)) {
        char *username = strtok(line, ",");
        char *password = strtok(NULL, "\n");
        if (strcmp(username, user.username) == 0 && strcmp(password, user.password) == 0) {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

int main() {
    int choice;
    User user;

    do {
        printf("1. Register\n");
        printf("2. Login\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter your username: ");
                scanf("%s", user.username);
                printf("Enter your password: ");
                scanf("%s", user.password);
                addUser(user);
                printf("User created successfully!\n");
                break;
            case 2:
                printf("Enter your username: ");
                scanf("%s", user.username);
                printf("Enter your password: ");
                scanf("%s", user.password);
                if (authenticateUser(user)) {
                    printf("Login successful!\n");
                } else {
                    printf("Incorrect username or password!\n");
                }
                break;
            case 3:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
                break;
        }
    } while (choice != 3);

    return 0;
}
